class appString {
  static String title = '';
  //static String  = '';
}
