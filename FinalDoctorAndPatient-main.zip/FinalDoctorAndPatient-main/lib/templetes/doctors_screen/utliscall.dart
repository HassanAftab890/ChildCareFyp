class Utils {
  static int appId = 531315481;
  static String appSignin =
      "30816bf6f5c72da8cf907af6e923e7a5d243537942269dc12d7a32166ac25575";
}
