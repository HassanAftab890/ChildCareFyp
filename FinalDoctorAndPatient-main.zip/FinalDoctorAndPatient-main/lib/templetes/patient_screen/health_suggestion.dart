import 'package:doctorandpatient/core/size_configuration.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Suggestions extends StatelessWidget {
  const Suggestions({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // leading: IconButton(
        //   icon: Icon(Icons.arrow_back),
        //   onPressed: () => Get.off(PatientDashboard()),
        // ),
        backgroundColor: Colors.red.shade900, 
        centerTitle: true,
        title:  Text(
          "HS".tr,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 5),
        child: ListView(
          children: [
   SizedBox(
              height: 10,
            ),
            Text('CS'.tr,style: TextStyle(fontWeight: FontWeight.bold),),
            SizedBox(
              height: 10,
            ),
            Card(
              elevation: 10,
              child: ListTile(
              
                title: Text("guide".tr,),
              ),
            ),
            //https://www.seattlechildrens.org/globalassets/images/health-and-safety/social/about-the-flu---facebook.jpg

            //https://th.bing.com/th/id/OIP.69LAgmb-1rHVfGCWbDVfCgHaFE?w=235&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7
            Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide1".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide2".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide3".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide4".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide5".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide6".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide7".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide8".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide9".tr,),
              ),
            ),
               Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide10".tr,),
              ),
            ),
                Card(
              elevation: 10,
              child: ListTile(
                
                title:  Text("guide11".tr,),
              ),
            ),

            //https://th.bing.com/th/id/R.7f4b41db445c04acdbdc07d64f4da199?rik=vnbGHkUVFugs8g&pid=ImgRaw&r=0
   
          ],
        ),
      ),
    );
  }
}
