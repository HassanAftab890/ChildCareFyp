class MyConst {
  static const int appId = 1983293281;
  //static const int appId = 450428291;


  static const String appSign =
      "22167453eed443ce8187ce5e0e373e054461c3a3169e9154c3aafdee4eaffba0";
}
